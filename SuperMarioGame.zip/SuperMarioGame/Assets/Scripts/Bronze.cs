﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BronzeCoin : ICoins

{
    public EnCoinType CoinType
    {
        get { return EnCoinType.Bronze; }
    }
    public int TotalCoins { get; set; }

    public void GetDisplayOfCollectingCoins()

        //GetExtrinsicState()
    {
        // This method would display a graphical representation of a Bronze Coin.

        //Console.WriteLine(string.Format("Displaying a graphical object of {500} gold coin of value {100} collecting from bronze coins." , CoinType.ToString(), coinValue);
    }
}