﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoldCoin : ICoins
{
    public static object Console { get; private set; }
    public int TotalCoins { get; set; }

    public EnCoinType CoinType
    {
        get { return EnCoinType.Gold; }
    }

    public void GetDisplayOfCollectingCoins()
    {
        //This method would display graphical representation like 

        //GoldCoin.

       //Console.WriteLine(string.Format("Displaying a graphical object of {gold} coin of value { 500 } Collecting from Coins". , CoinType.ToString(), coinValue)
                                  //    );
    }
}

