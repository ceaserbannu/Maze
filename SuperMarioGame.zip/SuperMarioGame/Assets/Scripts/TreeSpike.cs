﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace MarioGame
{
    public class TreeSpike : Spike
    {
        public override void Touch(Player player)
        {
            Console.Write("Player touched the tree... ");
        }
    }
}
