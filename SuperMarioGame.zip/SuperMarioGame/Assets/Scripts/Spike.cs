﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MarioGame
{
    public abstract class Spike
    {
        public abstract void Touch(Player player);

    }
}


