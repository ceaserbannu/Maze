﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Start is called before the first frame update

namespace MarioGame
{
    public class BushSpike : Spike
    {
        public override void Touch(Player player)
        {
            Console.Write("Player touched the Bush spike... ");
            //
            //
            //
        }
    }
}