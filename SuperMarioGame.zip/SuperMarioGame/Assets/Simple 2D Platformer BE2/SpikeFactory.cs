﻿using System;


namespace MarioGame
{
    public class SpikeFactory
    {
        public static Spike GetSpike(string SpikeType)
        {
            switch (SpikeType.ToUpper())
            {
                case "TREE":
                    return new TreeSpike();
                case "BUSH":
                    return new BushSpike();
            }

            throw new NotImplementedException();
        }
    }
}

