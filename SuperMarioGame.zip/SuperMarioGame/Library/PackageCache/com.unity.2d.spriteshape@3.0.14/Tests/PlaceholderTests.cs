using NUnit.Framework;

public class SpriteShapePlaceholder 
{
    [Test]
    public void PlaceHolderTest()
    {
        Assert.Pass("SpriteShape tests are in a separate package.");
    }
}
